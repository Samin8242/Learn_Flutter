package com.example.neumorphsim_music_player_ui

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
